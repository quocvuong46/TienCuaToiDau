-- ============================================================================
-- Tiền Của Tôi Đâu — 3. Dữ liệu Mẫu (Sample / Seed Data)
-- Hệ cơ sở dữ liệu: Supabase / PostgreSQL 15
-- ============================================================================

-- Tạm thời tắt các ràng buộc khóa ngoại để dễ dàng nạp dữ liệu không theo thứ tự chặt chẽ
SET session_replication_role = 'replica';

-- --------------------------------------------------------
-- 1. DỮ LIỆU MẪU CHO BẢNG profiles
-- --------------------------------------------------------
INSERT INTO profiles (id, full_name, avatar_url, created_at) VALUES 
('3645c5e8-6700-426f-a6a9-32622dcf57c2', 'Nguyễn Nam', NULL, '2026-05-27T09:36:54.215Z'),
('6031c462-b669-4172-8cf4-2a30004c828a', 'Đỗ Quốc Vương', NULL, '2026-05-29T06:25:02.835Z'),
('e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'Trần Hữu Nghĩa', NULL, '2026-05-29T12:32:08.620Z');

-- --------------------------------------------------------
-- 2. DỮ LIỆU MẪU CHO BẢNG categories
-- --------------------------------------------------------
-- Các danh mục cho người dùng Đỗ Quốc Vương
INSERT INTO categories (id, user_id, name, icon, color, type, is_default, created_at) VALUES 
('4ecb386a-0470-4523-9c67-96fff01482b9', '6031c462-b669-4172-8cf4-2a30004c828a', 'Ăn uống', 'UtensilsCrossed', '#FB923C', 'expense', true, '2026-05-29T06:25:10.000Z'),
('2bbe48ba-982e-42de-bed8-1cc42e5dbf65', '6031c462-b669-4172-8cf4-2a30004c828a', 'Di chuyển', 'Car', '#3B82F6', 'expense', true, '2026-05-29T06:25:10.000Z'),
('1f3ce202-7e28-4aa3-94c1-6b838737a446', '6031c462-b669-4172-8cf4-2a30004c828a', 'Mua sắm', 'ShoppingBag', '#EC4899', 'expense', true, '2026-05-29T06:25:10.000Z'),
('27cfbb8f-1268-4352-8a7b-c7e025355888', '6031c462-b669-4172-8cf4-2a30004c828a', 'Hóa đơn', 'Receipt', '#EF4444', 'expense', true, '2026-05-29T06:25:10.000Z'),
('ce25b6cf-7725-459a-be15-972dc1740e57', '6031c462-b669-4172-8cf4-2a30004c828a', 'Giải trí', 'Film', '#8B5CF6', 'expense', true, '2026-05-29T06:25:10.000Z'),
('a9c56c9a-9d31-423b-be58-c1b1eea42a4d', '6031c462-b669-4172-8cf4-2a30004c828a', 'Lương', 'Banknote', '#FFD100', 'income', true, '2026-05-29T06:25:10.000Z'),
('da41000c-6d41-4738-bee1-97946d16e343', '6031c462-b669-4172-8cf4-2a30004c828a', 'Thưởng', 'Gift', '#FFEE32', 'income', true, '2026-05-29T06:25:10.000Z');

-- Các danh mục cho người dùng Trần Hữu Nghĩa
INSERT INTO categories (id, user_id, name, icon, color, type, is_default, created_at) VALUES 
('35a8b452-5162-4734-a90a-c0397c520ae3', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'Ăn uống', 'UtensilsCrossed', '#FB923C', 'expense', true, '2026-05-29T12:32:08.000Z'),
('e397554e-9844-48ac-ba10-2fcd62cfef30', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'Di chuyển', 'Car', '#3B82F6', 'expense', true, '2026-05-29T12:32:08.000Z'),
('1312c993-1f27-41d5-8a44-d9c63c84d61b', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'Lương', 'Banknote', '#FFD100', 'income', true, '2026-05-29T12:32:08.000Z');

-- --------------------------------------------------------
-- 3. DỮ LIỆU MẪU CHO BẢNG wallets
-- --------------------------------------------------------
INSERT INTO wallets (id, user_id, name, type, icon, color, initial_balance, current_balance, created_at) VALUES 
-- Ví của Đỗ Quốc Vương
('fd1cd54c-6027-4866-9872-bcdd613ce352', '6031c462-b669-4172-8cf4-2a30004c828a', 'Ví Tiền mặt', 'cash', 'Wallet', '#FFD100', '0.00', '6151000.00', '2026-05-29T06:25:13.379Z'),

-- Ví của Trần Hữu Nghĩa (Ví dụ thực tế khớp demo)
('a1bee5ce-7588-4118-a465-78312aaf68d8', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'Ví Tiền mặt', 'cash', 'Wallet', '#FFD100', '0.00', '4463000.00', '2026-05-29T12:32:08.620Z'),
('744a7da4-1e8b-4b45-a8a1-f24966ccceb3', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'Ngân hàng', 'bank', 'Landmark', '#3B82F6', '0.00', '-500000.00', '2026-05-29T12:32:08.620Z'),

-- Ví của Nguyễn Nam
('ba48e05c-d6a1-433f-9a69-20a83157a881', '3645c5e8-6700-426f-a6a9-32622dcf57c2', 'Ví MoMo', 'e-wallet', 'Smartphone', '#EC4899', '3000000.00', '1995000.00', '2026-05-27T11:36:34.225Z'),
('dad4115f-9b72-48c4-ac00-f5ac9d0cbc89', '3645c5e8-6700-426f-a6a9-32622dcf57c2', 'Ví Tiền mặt', 'cash', 'Wallet', '#FFD100', '5000000.00', '4275000.00', '2026-05-27T11:36:34.121Z'),
('f5e249e7-5872-45eb-a7fb-ca6fc3eeb875', '3645c5e8-6700-426f-a6a9-32622dcf57c2', 'Techcombank', 'bank', 'CreditCard', '#EF4444', '30000000.00', '49450000.00', '2026-05-27T11:36:34.190Z');

-- --------------------------------------------------------
-- 4. DỮ LIỆU MẪU CHO BẢNG budgets
-- --------------------------------------------------------
INSERT INTO budgets (id, user_id, category_id, month, year, limit_amount, created_at) VALUES 
('c87810a6-ae7e-48ea-bc8c-dd498d3f4e9a', '3645c5e8-6700-426f-a6a9-32622dcf57c2', '4ecb386a-0470-4523-9c67-96fff01482b9', 5, 2026, '2000000.00', '2026-05-27T10:14:14.959Z');

-- --------------------------------------------------------
-- 5. DỮ LIỆU MẪU CHO BẢNG saving_goals
-- --------------------------------------------------------
INSERT INTO saving_goals (id, user_id, name, target_amount, current_amount, deadline, description, created_at) VALUES 
('b335150a-f448-4ee3-95fa-87503ed129e6', '3645c5e8-6700-426f-a6a9-32622dcf57c2', 'Mua iPhone 17 Pro', '35000000.00', '12000000.00', '2026-12-31', 'Tiết kiệm mua điện thoại mới', '2026-05-27T11:36:34.401Z');

-- --------------------------------------------------------
-- 6. DỮ LIỆU MẪU CHO BẢNG transactions
-- --------------------------------------------------------
INSERT INTO transactions (id, user_id, wallet_id, category_id, amount, type, description, merchant_name, image_url, transaction_date, ocr_confidence, created_at, updated_at) VALUES 
-- Giao dịch của Nguyễn Nam
('de0da12f-1301-40b3-b0bc-fa1f62225f6f', '3645c5e8-6700-426f-a6a9-32622dcf57c2', 'f5e249e7-5872-45eb-a7fb-ca6fc3eeb875', 'a9c56c9a-9d31-423b-be58-c1b1eea42a4d', '25000000.00', 'income', 'Nhận lương tháng 05', 'Công ty phần mềm', NULL, '2026-05-01', NULL, '2026-05-27T11:36:34.507Z', '2026-05-27T11:36:34.507Z'),
('21dda656-55eb-4d11-803c-18fdd92af71b', '3645c5e8-6700-426f-a6a9-32622dcf57c2', 'f5e249e7-5872-45eb-a7fb-ca6fc3eeb875', '27cfbb8f-1268-4352-8a7b-c7e025355888', '6000000.00', 'expense', 'Thanh toán tiền thuê nhà', 'Chủ nhà', NULL, '2026-05-02', NULL, '2026-05-27T11:36:34.586Z', '2026-05-27T11:36:34.586Z'),

-- Giao dịch của Trần Hữu Nghĩa (Khớp với các giá trị thu chi 5M thu nhập, 537K quán ăn, 500K ngân hàng)
('6f9f87b5-cdbd-4a25-8c0a-c23b1b67f01d', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'a1bee5ce-7588-4118-a465-78312aaf68d8', '1312c993-1f27-41d5-8a44-d9c63c84d61b', '5000000.00', 'income', 'Nhận lương tháng 05/2026', 'Công ty phần mềm', NULL, '2026-05-29', NULL, '2026-05-29T12:32:35.606Z', '2026-05-29T12:36:13.364Z'),
('1301f137-c256-4ad1-a79f-943ea9f9f9b2', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'a1bee5ce-7588-4118-a465-78312aaf68d8', '35a8b452-5162-4734-a90a-c0397c520ae3', '537000.00', 'expense', 'Quét hóa đơn ăn trưa bằng AI', 'QUAN AN THIEN TAN', 'https://vdocduzhjxbbytbtfucf.supabase.co/storage/v1/object/sign/receipts/receipt-demo.jpg', '2026-05-11', '95.00', '2026-05-29T12:34:43.075Z', '2026-05-29T12:34:43.075Z'),
('796d0f9f-e54a-49c1-9e50-07087153ef44', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', '744a7da4-1e8b-4b45-a8a1-f24966ccceb3', '35a8b452-5162-4734-a90a-c0397c520ae3', '500000.00', 'expense', 'Mua sắm gia dụng', 'Siêu thị CoopMart', NULL, '2026-05-29', NULL, '2026-05-29T12:36:56.717Z', '2026-05-29T12:36:56.717Z');

-- --------------------------------------------------------
-- 7. DỮ LIỆU MẪU CHO BẢNG receipt_items
-- --------------------------------------------------------
INSERT INTO receipt_items (id, transaction_id, name, quantity, price, created_at) VALUES 
('ac175320-d1fb-4ba2-9fd4-4219b529c305', '1301f137-c256-4ad1-a79f-943ea9f9f9b2', 'BÚN SINGAPORE', '2.00', '150000.00', '2026-05-29T12:34:45.000Z'),
('90f65d62-5560-464c-bddd-43ac4c9b1569', '1301f137-c256-4ad1-a79f-943ea9f9f9b2', 'MÌ GIÒN XÀO CHAY', '3.00', '79000.00', '2026-05-29T12:34:45.000Z');

-- --------------------------------------------------------
-- 8. DỮ LIỆU MẪU CHO BẢNG ai_prompt_logs
-- --------------------------------------------------------
INSERT INTO ai_prompt_logs (id, user_id, feature, prompt, result_summary, created_at) VALUES 
('dc6f8b03-9e31-4160-8554-e9249dea366e', 'e28f4414-7999-4b0d-99aa-b3bc1f7ea52e', 'ocr_receipt', 'receipt-1780057973000.jpg', '{"merchant":"QUAN AN THIEN TAN","total":537000,"confidence":0.95}', '2026-05-29T12:34:41.000Z');

-- Bật lại kiểm tra khóa ngoại
SET session_replication_role = 'origin';
