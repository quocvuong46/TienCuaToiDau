-- ============================================================================
-- Tiền Của Tôi Đâu — 2. Cấu hình Bảo mật Bộ nhớ (Supabase Storage RLS Policies)
-- Hướng dẫn: Chạy trong SQL Editor SAU KHI đã tạo 2 bucket `receipts` và `avatars` (Private)
-- ============================================================================

-- =================================-------------
-- A. BUCKET `receipts` — Ảnh hóa đơn quét AI
-- =================================-------------

-- 1. Cho phép người dùng tải ảnh lên thư mục cá nhân của mình
CREATE POLICY "Receipt upload own folder" ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'receipts' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 2. Cho phép người dùng đọc ảnh trong thư mục cá nhân của mình
CREATE POLICY "Receipt read own folder" ON storage.objects FOR SELECT
USING (
  bucket_id = 'receipts' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 3. Cho phép người dùng xóa ảnh trong thư mục cá nhân của mình
CREATE POLICY "Receipt delete own folder" ON storage.objects FOR DELETE
USING (
  bucket_id = 'receipts' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);


-- =================================-------------
-- B. BUCKET `avatars` — Ảnh đại diện người dùng
-- =================================-------------

-- 1. Cho phép người dùng tải ảnh đại diện lên thư mục cá nhân của mình
CREATE POLICY "Avatar upload own folder" ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 2. Cho phép người dùng đọc ảnh đại diện trong thư mục cá nhân của mình
CREATE POLICY "Avatar read own folder" ON storage.objects FOR SELECT
USING (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 3. Cho phép người dùng cập nhật ảnh đại diện của mình
CREATE POLICY "Avatar update own folder" ON storage.objects FOR UPDATE
USING (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- 4. Cho phép người dùng xóa ảnh đại diện của mình
CREATE POLICY "Avatar delete own folder" ON storage.objects FOR DELETE
USING (
  bucket_id = 'avatars' 
  AND (storage.foldername(name))[1] = auth.uid()::text
);
